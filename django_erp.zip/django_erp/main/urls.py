from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('employees/', views.employees, name='employees'),
    path('add_employee/', views.add_employee, name='add_employee'),
    path('products/', views.products, name='products'),
    path('add_product/', views.add_product, name='add_product'),
    path('sales/', views.sales, name='sales'),
    path('add_sale/', views.add_sale, name='add_sale'),
]
