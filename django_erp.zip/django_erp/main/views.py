from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Employee, Product, Sale

# Home route
def index(request):
    return render(request, 'index.html')

# Employee Routes
def employees(request):
    employees = Employee.objects.all()
    return render(request, 'employees.html', {'employees': employees})

def add_employee(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        department = request.POST.get('department')
        salary = request.POST.get('salary')

        new_employee = Employee(name=name, department=department, salary=salary)
        new_employee.save()
        messages.success(request, 'Employee added successfully')
        return redirect('employees')

    return render(request, 'add_employee.html')  # Show form for adding employee if not POST

# Product Routes
def products(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})

def add_product(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        stock = request.POST.get('stock')
        price = request.POST.get('price')

        new_product = Product(name=name, stock=int(stock), price=float(price))
        new_product.save()
        messages.success(request, 'Product added successfully')
        return redirect('products')

    return render(request, 'add_product.html')  # Show form for adding product if not POST

# Sales Routes
def sales(request):
    sales = Sale.objects.select_related('product').all()  # Use select_related for better performance
    products = Product.objects.all()  # Fetch products for the dropdown
    return render(request, 'sales.html', {'sales': sales, 'products': products})

def add_sale(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = int(request.POST.get('quantity'))

        # Use get_object_or_404 for better error handling
        product = get_object_or_404(Product, id=product_id)

        if product.stock >= quantity:
            total_price = product.price * quantity
            sale = Sale(product=product, quantity=quantity, total_price=total_price)
            sale.save()

            product.stock -= quantity
            product.save()

            messages.success(request, 'Sale recorded successfully')
        else:
            messages.error(request, 'Not enough stock for this sale')

        return redirect('sales')

    # If not POST, render the sales form (optional)
    return render(request, 'add_sale.html')  # Render add sale form
